import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import zipfile
import sys
import run_local


class LocalTest(unittest.TestCase):
    def test_unpack_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t); archive=root/'input.zip'; target=root/'data'
            with zipfile.ZipFile(archive,'w') as z:
                z.writestr('mission02_wavlm4_data/metadata.json','{}')
            run_local.unpack(archive,target)
            self.assertTrue((target/'mission02_wavlm4_data/metadata.json').is_file())
            with self.assertRaises(ValueError):run_local.unpack(archive,target)
            with zipfile.ZipFile(root/'bad.zip','w') as z:z.writestr('../escape.txt','bad')
            with self.assertRaises(ValueError):run_local.unpack(root/'bad.zip',root/'bad')

    def test_local_train_has_no_drive_no_time_limit(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t); data=root/'data';data.mkdir()
            (data/'metadata.json').write_text('{}')
            args=['run_local.py','train','--data',str(data),'--output',str(root/'out')]
            with patch.object(sys,'argv',args),patch.object(run_local,'gpu_check'),patch.object(run_local.subprocess,'run') as launch:
                run_local.main()
                command=launch.call_args.args[0]
                self.assertEqual(command[command.index('--max-minutes')+1],'0')
                self.assertIn('--resume',command)
                self.assertFalse(any('/content/drive' in part for part in command))


if __name__=='__main__':unittest.main()
