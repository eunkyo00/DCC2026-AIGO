import contextlib
import csv
import io
import json
import sys
import tempfile
import unittest
import os
os.environ['USE_TF'] = '0'
os.environ['USE_FLAX'] = '0'
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
import soundfile as sf
import torch
from transformers import WavLMConfig, WavLMModel
from model import WavLM4Classifier, load_checkpoint
from prepare import partition, export_split
from data import WaveDataset, collate, verify
import train
import inference


def tiny_config():
    return WavLMConfig(hidden_size=16,num_hidden_layers=4,num_attention_heads=2,
        intermediate_size=32,conv_dim=(8,8,8,8,8,8,8),
        num_conv_pos_embeddings=8,num_conv_pos_embedding_groups=2,
        hidden_dropout=0.,attention_dropout=0.,activation_dropout=0.,feat_proj_dropout=0.,
        layerdrop=0.,apply_spec_augment=False)


class PipelineTest(unittest.TestCase):
    def test_four_blocks_equal_full_hidden4(self):
        cfg=tiny_config();cfg.num_hidden_layers=12
        full=WavLMModel(cfg).eval()
        short=WavLM4Classifier(cfg.to_dict()).eval()
        short.backbone.load_state_dict({k:v for k,v in full.state_dict().items()
            if not k.startswith('encoder.layers.') or int(k.split('.')[2])<4})
        x=torch.randn(2,1600);mask=torch.ones_like(x,dtype=torch.long)
        with torch.no_grad():
            expected=full(x,attention_mask=mask,output_hidden_states=True).hidden_states[4]
            actual=short.backbone(x,attention_mask=mask).last_hidden_state
        torch.testing.assert_close(expected,actual)
        self.assertEqual(len(short.backbone.encoder.layers),4)
        short.set_stage(True);short.train()
        loss=short(x,mask).sum();loss.backward()
        self.assertIsNone(short.backbone.encoder.layers[0].feed_forward.intermediate_dense.weight.grad)
        self.assertIsNotNone(short.backbone.encoder.layers[3].feed_forward.intermediate_dense.weight.grad)
        self.assertFalse(short.backbone.encoder.layers[0].training)

    def test_preparation_resume_offline_inference(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); audio=root/'wav';audio.mkdir()
            annotation=root/'json';annotation.mkdir()
            rows=[]
            for call in range(20):
                path=audio/f'call{call}.wav'
                sf.write(path,np.sin(np.arange(8000)*.07).astype(np.float32)*.1,8000,subtype='PCM_16')
                for j in range(2):
                    rows.append(dict(stem=path.stem,wav_path=str(path),utterance_id=str(j),
                                     startAt=j*400,endAt=(j+1)*400,speaker=j))
                (annotation/f'{path.stem}.json').write_text(json.dumps(dict(utterances=[
                    dict(startAt=0,endAt=400,speaker='IGNORE',text='IGNORE'),
                    dict(startAt=400,endAt=800,speaker='IGNORE',text='IGNORE')])))
            frame=pd.DataFrame(rows)
            frames=partition(frame.iloc[:36],frame.iloc[36:],8,2)
            self.assertFalse(set(frames['fit'].stem)&set(frames['dev'].stem))
            data=root/'data';data.mkdir()
            meta=dict(sample_rate=8000,model_seconds=3,source_hashes={'synthetic':'test'},splits={})
            for split,f in frames.items():meta['splits'][split]=export_split(f,data,split,6)
            (data/'metadata.json').write_text(json.dumps(meta))
            verify(data)
            x,m,y=collate([WaveDataset(data,'fit')[0]])
            self.assertEqual(x.shape,(1,48000));self.assertEqual(m.sum().item(),6400)
            output=root/'output'
            args=['train.py','--data',str(data),'--output',str(output),'--epochs','1',
                  '--batch-size','2','--warmup-steps','1','--eval-every','2','--save-every','1',
                  '--cpu-test','--resume']
            real_save=train.atomic_save
            def interrupt_after_saved_batch(path,value):
                real_save(path,value)
                if path.name=='last_checkpoint.pt' and value['step']==1:
                    raise RuntimeError('simulated disconnect')
            with (patch.object(sys,'argv',args),patch.object(WavLM4Classifier,'pretrained',
                    side_effect=lambda:(WavLM4Classifier(tiny_config()),'synthetic-test')),
                    patch.object(train,'atomic_save',side_effect=interrupt_after_saved_batch),self.assertRaisesRegex(RuntimeError,'simulated disconnect')):
                train.main()
            self.assertEqual(load_checkpoint(output/'last_checkpoint.pt')[1]['offset'],2)
            with patch.object(sys,'argv',args),patch.object(WavLM4Classifier,'pretrained',side_effect=AssertionError('network forbidden')):
                train.main()
            model,state=load_checkpoint(output/'best_model.pt')
            self.assertEqual(state['threshold'],.5)
            self.assertEqual(state['signature']['policy'],train.POLICY)
            with patch.object(sys,'argv',args),patch.object(WavLM4Classifier,'pretrained',side_effect=AssertionError('network forbidden')):
                train.main()
            self.assertEqual(load_checkpoint(output/'last_checkpoint.pt')[1]['step'],4)
            args_bad=list(args);args_bad[args_bad.index('--batch-size')+1]='1'
            with patch.object(sys,'argv',args_bad),self.assertRaises(ValueError):train.main()
            out=root/'result.csv'
            state['threshold']=.99  # A legacy stored threshold must never override .5.
            state['model']['classifier.4.weight'].zero_()
            state['model']['classifier.4.bias'].zero_()  # sigmoid(0)=0.5 must map to 1.
            torch.save(state,output/'best_model.pt')
            infer_args=['inference.py','--audio_dir',str(audio),'--label_dir',str(annotation),
                        '--ckpt_path',str(output/'best_model.pt'),'--output',str(out),'--batch_size','2']
            with patch.object(sys,'argv',infer_args),patch.object(WavLMModel,'from_pretrained',side_effect=AssertionError('network forbidden')):
                inference.main()
            with out.open(encoding='utf-8-sig') as f: result=list(csv.DictReader(f))
            self.assertEqual(len(result),40)
            self.assertTrue(all(r['speaker'] in ('0','1') for r in result))
            self.assertTrue(all(r['speaker']=='1' for r in result))


if __name__=='__main__':
    torch.set_num_threads(2)
    unittest.main()
