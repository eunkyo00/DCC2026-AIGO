"""Offline, one-command Mission 2 inference. Ignores text/speaker annotations."""
import argparse
import csv
import json
import time
from pathlib import Path
import numpy as np
import soundfile as sf
import torch
from scipy.signal import resample_poly
from data import collate
from model import load_checkpoint
from train import autocast, atomic_json


def index(root, suffix):
    result = {}
    for p in root.rglob('*'):
        if p.is_file() and p.suffix.lower() == suffix:
            if p.stem in result:
                raise ValueError(f'Duplicate stem: {p.stem}')
            result[p.stem] = p
    return result


@torch.inference_mode()
def main():
    p=argparse.ArgumentParser()
    p.add_argument('--audio_dir',type=Path,required=True)
    p.add_argument('--label_dir',type=Path,required=True)
    p.add_argument('--ckpt_path',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--batch_size',type=int,default=16)
    a=p.parse_args()
    if a.batch_size<1: p.error('batch_size must be positive')
    model,state=load_checkpoint(a.ckpt_path)  # Config and all weights come from local file.
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device).eval()
    wavs,labels=index(a.audio_dir,'.wav'),index(a.label_dir,'.json')
    if not wavs or set(wavs)!=set(labels):
        raise ValueError('Empty input, missing pair or extra WAV/JSON; refusing silent omissions')
    started=time.monotonic()
    a.output.parent.mkdir(parents=True,exist_ok=True)
    temporary=Path(str(a.output)+'.tmp')
    count=0
    with temporary.open('w',encoding='utf-8-sig',newline='') as out:
        writer=csv.writer(out)
        writer.writerow(['audio file name','startAt','endAt','speaker'])
        pending,info=[],[]
        def flush():
            nonlocal count
            if not pending: return
            x,mask,_=collate(pending)
            with autocast(device):
                probabilities=model(x.to(device),mask.to(device)).float().sigmoid()
            predicted=(probabilities>=.5).long().cpu().tolist()
            for row,label in zip(info,predicted): writer.writerow([*row,label])
            count+=len(pending)
            pending.clear();info.clear()
        for stem,path in sorted(wavs.items()):
            annotation=json.loads(labels[stem].read_text(encoding='utf-8-sig'))
            utterances=annotation.get('utterances')
            if not isinstance(utterances,list) or not utterances:
                raise ValueError(f'Missing utterances: {stem}')
            with sf.SoundFile(path) as f:
                if f.samplerate!=8000 or f.channels!=1:
                    raise ValueError('Expected original 8kHz mono WAV')
                for u in utterances:
                    begin,end=u['startAt'],u['endAt']
                    lo,hi=round(float(begin)*8),round(float(end)*8)
                    if not 0<=lo<hi<=len(f): raise ValueError(f'Invalid boundary: {stem}')
                    if hi-lo>24000: lo+=(hi-lo-24000)//2;hi=lo+24000
                    f.seek(lo)
                    wave=resample_poly(f.read(hi-lo,dtype='int16').astype(np.float32)/32768,2,1).astype(np.float32)
                    wave=np.pad(wave,(0,max(0,400-len(wave))))
                    pending.append((torch.from_numpy(wave),0))
                    info.append((path.name,begin,end))
                    if len(pending)==a.batch_size: flush()
        flush()
    temporary.replace(a.output)
    elapsed=time.monotonic()-started
    atomic_json(a.output.with_suffix('.timing.json'),dict(rows=count,threshold=.5,
        seconds=elapsed,milliseconds_per_sample=elapsed*1000/max(1,count),batch_size=a.batch_size,
        hardware=torch.cuda.get_device_name(0) if device.type=='cuda' else 'CPU',
        total_parameters=sum(x.numel() for x in model.parameters()),
        active_parameters=sum(x.numel() for x in model.parameters()),
        timing_scope='WAV_JSON_read_preprocess_inference_CSV_excludes_checkpoint_load'))
    print(f'CSV={a.output} rows={count} threshold=0.5 seconds={elapsed:.2f}',flush=True)


if __name__=='__main__': main()
