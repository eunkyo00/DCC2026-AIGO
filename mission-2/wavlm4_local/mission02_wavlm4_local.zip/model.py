"""Truncated WavLM: feature encoder plus EXACTLY four transformer blocks."""
import os
os.environ['USE_TF'] = '0'
os.environ['USE_FLAX'] = '0'
import torch
from torch import nn
from transformers import WavLMConfig, WavLMModel


class WavLM4Classifier(nn.Module):
    def __init__(self, config=None):
        super().__init__()
        config = WavLMConfig(**config) if isinstance(config, dict) else (config or WavLMConfig())
        config.num_hidden_layers = 4
        config.layerdrop = 0.0
        config.apply_spec_augment = False
        self.backbone = WavLMModel(config)
        h = config.hidden_size
        self.attention = nn.Sequential(nn.Linear(h, 128), nn.Tanh(), nn.Linear(128, 1))
        self.classifier = nn.Sequential(nn.LayerNorm(h*2), nn.Linear(h*2, 256),
                                        nn.GELU(), nn.Dropout(.2), nn.Linear(256, 1))
        self.set_stage(False)

    @classmethod
    def pretrained(cls):
        original = WavLMModel.from_pretrained('microsoft/wavlm-base-plus')
        revision = getattr(original.config, '_commit_hash', None)
        model = cls(original.config.to_dict())
        state = {k: v for k, v in original.state_dict().items()
                 if not k.startswith('encoder.layers.') or int(k.split('.')[2]) < 4}
        model.backbone.load_state_dict(state, strict=True)
        return model, revision

    def set_stage(self, finetune):
        for p in self.backbone.parameters():
            p.requires_grad = False
        for block in self.backbone.encoder.layers[2:4]:
            for p in block.parameters():
                p.requires_grad = finetune
        self.finetune = finetune

    def train(self, mode=True):
        super().train(mode)
        self.backbone.eval()
        if mode and self.finetune:
            for block in self.backbone.encoder.layers[2:4]:
                block.train()
        return self

    def forward(self, waveform, attention_mask):
        h = self.backbone(waveform, attention_mask=attention_mask).last_hidden_state.float()
        lengths = self.backbone._get_feat_extract_output_lengths(attention_mask.sum(-1)).clamp(min=1)
        valid = torch.arange(h.shape[1], device=h.device)[None] < lengths[:, None]
        scores = self.attention(h).squeeze(-1).float().masked_fill(~valid, -1e9)
        weights = scores.softmax(-1).unsqueeze(-1)
        mean = (weights*h).sum(1)
        std = ((weights*(h-mean[:, None]).square()).sum(1).clamp_min(1e-5)).sqrt()
        return self.classifier(torch.cat([mean, std], -1)).squeeze(-1)


def load_checkpoint(path):
    state = torch.load(path, map_location='cpu', weights_only=True)
    if state['policy'] != 'fixed_0.5_training_calls_only_v1':
        raise ValueError('Unknown checkpoint policy')
    model = WavLM4Classifier(state['config'])
    model.load_state_dict(state['model'], strict=True)
    return model, state
