"""Windows/Linux NVIDIA launcher. No Colab, Drive or cloud storage dependency."""
import argparse
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def unpack(source, destination):
    if destination.exists() and any(destination.iterdir()):
        raise ValueError('Destination must be empty to prevent mixed datasets')
    with zipfile.ZipFile(source) as z:
        for member in z.infolist():
            path=Path(member.filename)
            if path.is_absolute() or '..' in path.parts or '\\' in member.filename or ':' in member.filename:
                raise ValueError('Unsafe ZIP member')
            if path.parts and path.parts[0] not in ('mission02_wavlm4_data','mission02_wavlm4_official'):
                raise ValueError('Expected a WavLM4 waveform ZIP, not a Mel/code ZIP')
        destination.mkdir(parents=True,exist_ok=True)
        needed=sum(m.file_size for m in z.infolist())
        if shutil.disk_usage(destination).free < needed + 3*1024**3:
            raise ValueError('Need extracted data size plus 3 GiB checkpoint headroom')
        bad=z.testzip()
        if bad: raise ValueError(f'Damaged ZIP: {bad}')
        for i,member in enumerate(z.infolist()):
            z.extract(member,destination)
            if i%25==0: print(f'Extract {i+1}/{len(z.infolist())}',flush=True)
    print(f'Data extracted to {destination.resolve()}',flush=True)


def gpu_check():
    import torch
    import transformers
    if not torch.cuda.is_available():
        raise RuntimeError('NVIDIA CUDA GPU unavailable. Check driver and CUDA-enabled PyTorch. This launcher does not use Apple MPS/CPU.')
    if torch.version.cuda is None:
        raise RuntimeError('Install NVIDIA CUDA PyTorch, not CPU/ROCm build')
    # A real CUDA operation also catches unsupported GPU architecture/driver builds.
    x=torch.ones(32,32,device='cuda')
    value=(x@x).sum().item()
    assert value==32768
    print(json.dumps(dict(python=sys.version,torch=str(torch.__version__),
          transformers=transformers.__version__,cuda=torch.version.cuda,
          gpu=torch.cuda.get_device_name(0),vram_gib=torch.cuda.get_device_properties(0).total_memory/1024**3),indent=2))


def inspect_checkpoint(path):
    from model import load_checkpoint
    model,state=load_checkpoint(path)
    required={'optimizer','scaler','step','epoch','offset','best','bad','history','signature',
              'revision','torch_rng','cuda_rng','source_hashes'}
    missing=required-state.keys()
    if missing: raise ValueError(f'Not resumable: missing {sorted(missing)}')
    print(json.dumps(dict(file=str(path),size_mib=path.stat().st_size/1024**2,
        step=state['step'],epoch=state['epoch'],offset=state['offset'],
        internal_best=state['best'],signature=state['signature']),indent=2))
    signature=state['signature']
    del model,state
    return signature


def main():
    p=argparse.ArgumentParser()
    commands=p.add_subparsers(dest='action',required=True)
    commands.add_parser('doctor')
    z=commands.add_parser('unpack')
    z.add_argument('--zip',type=Path,required=True)
    z.add_argument('--destination',type=Path,default=Path('data'))
    ck=commands.add_parser('checkpoint')
    ck.add_argument('path',type=Path)
    for name in ('train','benchmark','evaluate'):
        c=commands.add_parser(name)
        c.add_argument('--data',type=Path,default=Path('data/mission02_wavlm4_official' if name=='evaluate' else 'data/mission02_wavlm4_data'))
        c.add_argument('--output',type=Path,default=Path('outputs/wavlm4'))
        c.add_argument('--batch-size',type=int)
        if name=='train':
            c.add_argument('--epochs',type=int)
            c.add_argument('--max-minutes',type=float,default=0)
        if name=='evaluate':
            c.add_argument('--checkpoint',type=Path,default=Path('outputs/wavlm4/best_model.pt'))
    a=p.parse_args()
    if a.action=='unpack': unpack(a.zip,a.destination);return
    if a.action=='checkpoint': inspect_checkpoint(a.path);return
    gpu_check()
    if a.action=='doctor': return
    if not (a.data/'metadata.json').is_file():
        raise ValueError(f'No metadata.json in {a.data}. Extract the waveform ZIP first.')
    a.output.mkdir(parents=True,exist_ok=True)
    if shutil.disk_usage(a.output).free<3*1024**3:
        raise ValueError('Less than 3 GiB free on output disk. Free space before training.')
    mode=dict(train='train',benchmark='benchmark',evaluate='official')[a.action]
    batch=a.batch_size or 16
    args=[sys.executable,'-u',str(ROOT/'train.py'),'--mode',mode,'--data',str(a.data),'--output',str(a.output)]
    if a.action=='train':
        last=a.output/'last_checkpoint.pt'
        epochs=a.epochs or 6
        warmup=200
        if last.is_file():
            saved=inspect_checkpoint(last)  # Fail explicitly on truncated/invalid Drive copies.
            batch=a.batch_size if a.batch_size is not None else saved['batch_size']
            epochs=a.epochs if a.epochs is not None else saved['epochs']
            warmup=saved['warmup_steps']
        args+=['--epochs',str(epochs),'--warmup-steps',str(warmup),
               '--max-minutes',str(a.max_minutes),'--resume']
    elif a.action=='evaluate': args+=['--checkpoint',str(a.checkpoint)]
    args+=['--batch-size',str(batch)]
    print('Local command:',subprocess.list2cmdline(args),flush=True)
    subprocess.run(args,check=True)


if __name__=='__main__': main()
