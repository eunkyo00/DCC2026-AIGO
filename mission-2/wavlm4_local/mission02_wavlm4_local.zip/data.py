"""Only waveform enters model. Call identifiers are for audit, never features."""
import bisect
import json
from pathlib import Path
import numpy as np
import torch
from scipy.signal import resample_poly
from torch.utils.data import Dataset
from prepare import digest


def verify(root):
    meta = json.loads((Path(root) / 'metadata.json').read_text())
    if meta['sample_rate'] != 8000 or meta['model_seconds'] != 3:
        raise ValueError('Unexpected preprocessing')
    if 'fit' in meta['splits']:
        if set(meta['splits']['fit']['calls']) & set(meta['splits']['dev']['calls']):
            raise ValueError('Call leakage')
    for split in meta['splits'].values():
        for shard in split['shards']:
            for f in shard['files'].values():
                if digest(Path(root) / f['path']) != f['sha256']:
                    raise ValueError(f'Corrupted upload: {f["path"]}')
    return meta


class WaveDataset(Dataset):
    def __init__(self, root, split, epoch=0):
        self.root, self.split, self.epoch = Path(root), split, epoch
        self.meta = json.loads((self.root / 'metadata.json').read_text())
        self.info = self.meta['splits'][split]
        self.ends = np.cumsum([s['samples'] for s in self.info['shards']]).tolist()
        self.arrays = [{k: np.load(self.root / v['path'], mmap_mode='r', allow_pickle=False)
                        for k, v in s['files'].items() if k != 'ids'} for s in self.info['shards']]

    def __len__(self):
        return self.info['samples']

    def __getitem__(self, index):
        shard = bisect.bisect_right(self.ends, index)
        local = index - (self.ends[shard-1] if shard else 0)
        a = self.arrays[shard]
        x = a['audio'][a['offsets'][local]:a['offsets'][local+1]]
        if len(x) > 24000:
            if self.split == 'fit':
                rng = np.random.default_rng(np.random.SeedSequence([20261010, self.epoch, index]))
                start = int(rng.integers(len(x)-24000+1))
            else:
                start = (len(x)-24000)//2
            x = x[start:start+24000]
        x = resample_poly(x.astype(np.float32)/32768, 2, 1).astype(np.float32)
        # WavLM CNN minimum receptive field is 400 samples at 16kHz.
        # Extremely short utterances keep one feature frame, with explicit zero-padding.
        x = np.pad(x, (0, max(0, 400-len(x))))
        return torch.from_numpy(x), int(a['labels'][local])


def collate(rows):
    lengths = torch.tensor([len(x) for x, _ in rows])
    # Fixed padding avoids batch-composition-dependent group normalization.
    x = torch.zeros(len(rows), 48000)
    for i, (wave, _) in enumerate(rows):
        x[i, :len(wave)] = wave
    mask = torch.arange(48000)[None, :] < lengths[:, None]
    return x, mask.long(), torch.tensor([y for _, y in rows])
