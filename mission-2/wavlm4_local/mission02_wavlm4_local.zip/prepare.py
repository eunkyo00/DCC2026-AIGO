"""Mac CPU: create label-independent waveform shards, with call-level split."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile
import numpy as np
import pandas as pd
import soundfile as sf


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def partition(train, valid, train_count, dev_count, seed=20261010):
    if set(train.stem) & set(valid.stem):
        raise ValueError('Official split call overlap')
    calls = np.array(sorted(train.stem.unique()))
    np.random.default_rng(seed).shuffle(calls)
    dev_calls = set(calls[:max(1, round(len(calls) * .1))])
    dev = train[train.stem.isin(dev_calls)]
    fit = train[~train.stem.isin(dev_calls)]
    return {k: f.sample(min(n, len(f)), random_state=seed).sort_values(['stem', 'startAt'])
            for k, f, n in [('fit', fit, train_count), ('dev', dev, dev_count)]}


def export_split(frame, root, name, seconds):
    folder = root / name
    folder.mkdir(parents=True)
    records, chunks, offsets, ys, identities = [], [], [0], [], []
    source, handle = None, None
    def flush():
        if not ys:
            return
        prefix = f'{len(records):04d}'
        arrays = dict(audio=np.concatenate(chunks), offsets=np.array(offsets, dtype=np.int64),
                      labels=np.array(ys, dtype=np.int64), ids=np.array(identities))
        files = {}
        for key, array in arrays.items():
            p = folder / f'{prefix}_{key}.npy'
            np.save(p, array, allow_pickle=False)
            files[key] = dict(path=str(p.relative_to(root)), sha256=digest(p))
        records.append(dict(samples=len(ys), files=files))
        chunks.clear(); offsets[:] = [0]; ys.clear(); identities.clear()
    try:
        for i, r in enumerate(frame.itertuples(index=False)):
            if r.wav_path != source:
                if handle is not None:
                    handle.close()
                handle = sf.SoundFile(r.wav_path)
                source = r.wav_path
                if handle.samplerate != 8000 or handle.channels != 1:
                    raise ValueError(f'Expected 8k mono: {source}')
            start, end = round(float(r.startAt) * 8), round(float(r.endAt) * 8)
            if not 0 <= start < end <= len(handle):
                raise ValueError(f'Invalid utterance boundary: {r.stem}/{r.utterance_id}')
            cap = int(seconds * 8000)
            if end - start > cap:
                start += (end - start - cap) // 2
                end = start + cap
            handle.seek(start)
            chunks.append(handle.read(end - start, dtype='int16'))
            offsets.append(offsets[-1] + len(chunks[-1]))
            if int(r.speaker) not in (0, 1):
                raise ValueError('Unknown speaker')
            ys.append(int(r.speaker))
            identities.append(f'{r.stem}/{r.utterance_id}')
            if len(ys) == 2000:
                flush()
                print(f'{name}: {i+1:,}/{len(frame):,}', flush=True)
        flush()
    finally:
        if handle is not None:
            handle.close()
    return dict(samples=len(frame), calls=sorted(frame.stem.unique().tolist()), shards=records,
                class_counts={str(k): int(v) for k, v in frame.speaker.value_counts().items()})


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--manifests', type=Path, default=Path(__file__).resolve().parents[1] / 'mission02/manifests')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--train-count', type=int, default=100000)
    p.add_argument('--dev-count', type=int, default=4000)
    p.add_argument('--official', action='store_true', help='Separate package of ALL official Validation utterances')
    a = p.parse_args()
    if a.train_count < 1 or a.dev_count < 1:
        p.error('Counts must be positive')
    if a.output.exists() or a.output.with_suffix('.zip').exists():
        p.error('Output already exists: do not overwrite or mix packages')
    paths = {s: a.manifests / f'mission2_speaker_{s}.csv' for s in ('Training', 'Validation')}
    train, valid = [pd.read_csv(paths[s], encoding='utf-8-sig') for s in paths]
    frames = partition(train, valid, a.train_count, a.dev_count)
    if a.official:
        frames = {'official': valid.sort_values(['stem', 'startAt'])}
    a.output.mkdir(parents=True)
    meta = dict(version=1, seed=20261010, sample_rate=8000, model_seconds=3,
                stored_seconds=3 if a.official else 6,
                source_hashes={s: digest(path) for s, path in paths.items()}, splits={})
    for name, frame in frames.items():
        meta['splits'][name] = export_split(frame, a.output, name, meta['stored_seconds'])
    (a.output / 'metadata.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2))
    destination = a.output.with_suffix('.zip')
    print('Compressing (CPU only)...', flush=True)
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=1) as z:
        for path in sorted(a.output.rglob('*')):
            if path.is_file():
                z.write(path, str(path.relative_to(a.output.parent)))
    print(f'READY: {destination}\nSize: {destination.stat().st_size / 1e9:.2f} GB', flush=True)


if __name__ == '__main__':
    main()
