# 로컬 NVIDIA GPU 실행 안내

Colab, Google Drive 마운트, 컴퓨팅 단위가 필요 없습니다. Windows/Linux의 NVIDIA CUDA GPU 기준입니다. 현재 Intel Mac에서 GPU 학습하는 설정은 아닙니다. 다른 GPU PC의 성능은 T4 측정값과 다릅니다. 94%는 아직 검증하지 않은 목표입니다.

## 준비물

1. `mission02_wavlm4_local.zip`: 코드, 이 문서, 테스트. GPU PC에서 압축을 풉니다.
2. `mission02_wavlm4_data.zip`: 이미 Mac에서 만든 동일한 파형 ZIP을 GPU PC로 복사합니다. Drive 재업로드는 필요 없습니다.
3. 이어 학습하려면 Colab 결과 폴더의 `last_checkpoint.pt`, `best_model.pt`, `history.json`과 `.previous` 파일들을 별도 백업 폴더로 다운로드합니다. `.tmp`는 재개 파일로 사용하지 않습니다. 파일이 보인다는 것만으로 저장 성공은 아닙니다.

코드의 `mission02_wavlm4` 폴더를 VS Code로 열어 터미널을 실행합니다. 로컬 디스크에 파형 압축 해제 공간 외에 최소 3GiB 여유를 확보합니다. 초기 사전학습 모델 다운로드 캐시에도 여유가 필요합니다. 파일을 OneDrive/Drive 동기화 폴더에 두지 않는 것을 권장합니다.

## 1. Python 환경 설치

Python 3.11을 권장합니다. 전용 가상환경을 사용해 다른 프로젝트와 분리합니다.

Windows PowerShell:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
```

실행 정책 때문에 activate가 막히면 정책을 변경할 필요 없이 아래 명령의 `python`을 `.\.venv\Scripts\python.exe`로 바꿉니다.

Linux:

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
```

`nvidia-smi`로 GPU/드라이버를 확인한 뒤 **PyTorch 공식 설치 선택기**에서 해당 OS/Pip/Python/CUDA 조합의 명령을 실행합니다. GPU 모델에 맞지 않는 CUDA wheel을 임의로 설치하지 마세요. RTX 50 계열과 구형 GPU는 호환 빌드가 다를 수 있습니다.

https://pytorch.org/get-started/locally/

이 프로젝트는 torch가 필요하며 torchvision/torchaudio는 필수가 아닙니다. CUDA 버전과 torch 설치 명령을 모르겠으면 `nvidia-smi` 결과와 OS를 보내 주세요. CPU-only torch로 진행하지 않습니다.

```bash
python -m pip install -r requirements.txt
python run_local.py doctor
```

doctor는 GPU 이름/VRAM/Python/torch/CUDA를 출력하고 작은 CUDA 행렬 계산까지 검사합니다. 처음 학습 전에 성공해야 합니다.

## 2. 기존 파형 ZIP 압축 해제

ZIP을 코드 폴더 안에 복사한 경우:

```bash
python run_local.py unpack --zip mission02_wavlm4_data.zip
```

결과 위치는 `data/mission02_wavlm4_data`입니다. 이미 풀려 있으면 다시 실행하지 않습니다. unpack은 비어 있지 않은 대상 폴더에 덮어쓰지 않습니다. 다른 위치는 `--data` 옵션으로 지정할 수 있습니다. 원본 WAV와 Mac 절대경로 manifest를 이 PC로 옮길 필요는 없습니다.

## 3-A. 처음부터 새로 학습

```bash
python run_local.py benchmark
python run_local.py train
```

기본 batch-size 16, 6 epoch, 내부 검증 4회 연속 미개선이면 조기 종료합니다. **로컬에서는 30분 제한을 해제**했습니다. GPU 메모리가 부족하면 새 실험 폴더에서 `python run_local.py train --batch-size 8 --output outputs/wavlm4_bs8`로 시작합니다. 기존 실행의 batch-size를 바꾸어 재개할 수는 없습니다.

최대 60분씩 실행하려면 `python run_local.py train --max-minutes 60`을 사용합니다. 종료·재부팅 후 같은 명령으로 마지막 저장 batch부터 재개합니다. Ctrl+C 시 마지막 저장 이후 최대 100 step은 다시 계산할 수 있습니다. 잠자기 설정은 사용자가 확인합니다.

## 3-B. Colab 학습 이어서 하기

1. 다운로드한 원본 체크포인트들을 별도 폴더에 보존합니다. 기존 파일을 덮어쓰지 않습니다.
2. 우선 읽기/모델 구조 검사를 실행합니다.

```bash
python run_local.py checkpoint /path/to/downloaded/last_checkpoint.pt
```

3. 성공하면 **새 로컬 폴더 `outputs/wavlm4`**에 `last_checkpoint.pt`, 읽기 검사를 통과한 `best_model.pt`, `history.json`을 복사합니다. 이미 해당 폴더에서 다른 학습을 했다면 `--output outputs/wavlm4_resumed`처럼 별도 폴더를 사용합니다.
4. `python run_local.py train`을 실행합니다. checkpoint에서 batch-size/epochs/warmup 설정을 읽으며 데이터 해시가 다르면 중단합니다.

last가 손상됐다면 `.previous` 파일도 같은 명령으로 검사합니다. 정상 이전 사본을 **새 폴더에 복사하면서** 이름을 `last_checkpoint.pt`로 지정할 수 있습니다. 원본은 남깁니다. 그 경우 이전 step부터 재개합니다. 최신 best를 읽을 수 없거나 분실한 경우 과거 best 성능을 복구했다고 볼 수 없으며 제출 모델 선택을 별도 확인해야 합니다. optimizer 상태까지 검사하지만 GPU/torch 변경에 따른 비트 단위 동일성은 보장하지 않습니다.

## 4. 공식 전체 Validation

Training 내부 dev Accuracy는 공식 성능이 아닙니다. 학습 후 공식 데이터 ZIP을 기존 Mac에서 별도로 만듭니다.

```bash
cd /Users/mac/Documents/ChatGPT/DCC
./mission02/.venv_precompute/bin/python -u mission02_wavlm4/prepare.py --official --output mission02_wavlm4_official
```

생성한 `mission02_wavlm4_official.zip`을 GPU PC로 옮깁니다.

```bash
python run_local.py unpack --zip mission02_wavlm4_official.zip --destination official_data
python run_local.py evaluate --data official_data/mission02_wavlm4_official
```

`outputs/wavlm4/official_metrics.json`의 Accuracy가 공식 Validation 전체 111,947발화 기준입니다. 독립 Test 성능은 아닙니다. 다른 output 폴더에서 학습했다면 evaluate의 `--checkpoint`와 `--output`도 지정합니다.

## 5. 최종 입력 폴더에서 추론

```bash
python inference.py --audio_dir /path/to/wav --label_dir /path/to/json --ckpt_path outputs/wavlm4/best_model.pt --output outputs/mission2.csv
```

모든 판정 임계값은 0.5입니다. 추론은 로컬 config/weights를 사용하며 외부 모델 다운로드를 하지 않습니다. 원본 8kHz mono WAV와 JSON의 startAt/endAt으로 발화를 추출합니다. 전사 텍스트·발화 순서 등은 입력에 넣지 않습니다.

제출 전에 사용 환경을 `python -m pip freeze > requirements-lock.txt`로 기록하고, 별도 환경의 오프라인 실행을 다시 확인하세요. 이번 로컬 패키지 생성이 모델 성능 검증이나 제출 완료를 의미하지 않습니다.
