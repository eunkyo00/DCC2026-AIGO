"""Budgeted fine-tuning, internal call-level dev only, fixed decision threshold."""
import argparse
import json
import math
import os
import time
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from data import WaveDataset, collate, verify
from model import WavLM4Classifier, load_checkpoint
from prepare import digest

POLICY = 'fixed_0.5_training_calls_only_v1'


def atomic_json(path, value):
    tmp = Path(str(path)+'.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2))
    os.replace(tmp, path)


def atomic_save(path, value):
    # Rename on Drive is best effort. Keep previous copy for an interrupted write.
    tmp = Path(str(path)+'.tmp')
    torch.save(value, tmp)
    backup = Path(str(path)+'.previous')
    if path.exists():
        os.replace(path, backup)
    os.replace(tmp, path)


def autocast(device):
    return torch.autocast(device_type=device.type, dtype=torch.float16, enabled=device.type == 'cuda')


@torch.inference_mode()
def evaluate(model, dataset, device, batch_size):
    model.eval()
    cm = torch.zeros(2, 2, dtype=torch.long)
    loss_sum = 0.0
    started = time.monotonic()
    for i, (x, mask, y) in enumerate(DataLoader(dataset, batch_size=batch_size, collate_fn=collate)):
        with autocast(device):
            logits = model(x.to(device), mask.to(device))
        probabilities = logits.float().sigmoid().cpu()
        pred = (probabilities >= .5).long()
        cm += torch.bincount(y*2+pred, minlength=4).reshape(2, 2)
        loss_sum += torch.nn.functional.binary_cross_entropy_with_logits(logits.float().cpu(), y.float(), reduction='sum').item()
        if i % 100 == 0:
            print(f'evaluation {min((i+1)*batch_size,len(dataset)):,}/{len(dataset):,}', flush=True)
    if device.type == 'cuda':
        torch.cuda.synchronize()
    elapsed = time.monotonic()-started
    return dict(accuracy=cm.diag().sum().item()/len(dataset), threshold=.5,
                operator_recall=cm[0,0].item()/max(1,cm[0].sum().item()),
                caller_recall=cm[1,1].item()/max(1,cm[1].sum().item()),
                confusion_matrix=cm.tolist(), samples=len(dataset), loss=loss_sum/len(dataset),
                seconds=elapsed, milliseconds_per_sample=elapsed*1000/len(dataset),
                timing_scope='waveform_shard_read_resample_forward_excludes_original_WAV_JSON_io',
                batch_size=batch_size, hardware=torch.cuda.get_device_name(0) if device.type=='cuda' else 'CPU')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--data', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--mode', choices=['benchmark', 'train', 'official'], default='train')
    p.add_argument('--checkpoint', type=Path)
    p.add_argument('--batch-size', type=int, default=16)
    p.add_argument('--epochs', type=int, default=6)
    p.add_argument('--warmup-steps', type=int, default=200)
    p.add_argument('--eval-every', type=int, default=250)
    p.add_argument('--save-every', type=int, default=100)
    p.add_argument('--max-minutes', type=float, default=30, help='0 disables wall-clock limit (local GPU)')
    p.add_argument('--resume', action='store_true')
    p.add_argument('--cpu-test', action='store_true')
    a = p.parse_args()
    if min(a.batch_size,a.epochs,a.eval_every,a.save_every) < 1 or a.max_minutes<0 or a.warmup_steps<0:
        p.error('Invalid budget/configuration')
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    if device.type != 'cuda' and not a.cpu_test:
        raise RuntimeError('Connect T4 GPU before running this cell')
    torch.manual_seed(20261010)
    a.output.mkdir(parents=True, exist_ok=True)
    meta = verify(a.data)
    started = time.monotonic()
    if a.mode == 'official':
        if a.checkpoint is None:
            p.error('--checkpoint required')
        ds = WaveDataset(a.data, 'official')
        if len(ds) != 111947:
            raise ValueError('Full official Validation must contain 111947 utterances')
        model, state = load_checkpoint(a.checkpoint)
        if meta['source_hashes'] != state['source_hashes']:
            raise ValueError('Official source manifest mismatch')
        result = evaluate(model.to(device), ds, device, a.batch_size)
        result.update(scope='official_full_validation_not_independent_test',
                      checkpoint_sha256=digest(a.checkpoint),
                      total_parameters=sum(x.numel() for x in model.parameters()),
                      active_parameters=sum(x.numel() for x in model.parameters()))
        atomic_json(a.output/'official_metrics.json', result)
        print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
        return
    fit, dev = WaveDataset(a.data, 'fit'), WaveDataset(a.data, 'dev')
    signature = dict(policy=POLICY, metadata_sha256=digest(a.data/'metadata.json'),
                     batch_size=a.batch_size, epochs=a.epochs, warmup_steps=a.warmup_steps)
    last = a.output/'last_checkpoint.pt'
    state = None
    if a.mode == 'train' and last.exists():
        if not a.resume:
            raise ValueError('Output has a checkpoint. Use --resume or a new output directory.')
        model, state = load_checkpoint(last)
        if state['signature'] != signature:
            raise ValueError('Resume settings/data differ. Do not mix experiments.')
    elif a.mode == 'train' and (a.output/'best_model.pt').exists():
        raise ValueError('Missing last checkpoint. Restore last_checkpoint.pt.previous or use a new output directory.')
    else:
        print('Loading pretrained WavLM, keeping only blocks 1-4...', flush=True)
        model, revision = WavLM4Classifier.pretrained()
    model.to(device)
    model.set_stage(True)
    backbone = [p for p in model.backbone.parameters() if p.requires_grad]
    head = list(model.attention.parameters()) + list(model.classifier.parameters())
    optimizer = torch.optim.AdamW([dict(params=backbone,lr=1e-5),dict(params=head,lr=3e-4)], weight_decay=.01)
    scaler = torch.cuda.amp.GradScaler(enabled=device.type=='cuda')
    step, epoch, offset, best, bad = 0, 0, 0, -1., 0
    history = []
    if state:
        optimizer.load_state_dict(state['optimizer'])
        scaler.load_state_dict(state['scaler'])
        step,epoch,offset,best,bad = [state[k] for k in ['step','epoch','offset','best','bad']]
        history = state['history']
        revision = state['revision']
        torch.set_rng_state(state['torch_rng'])
        if device.type=='cuda':
            torch.cuda.set_rng_state_all(state['cuda_rng'])
    batches = math.ceil(len(fit)/a.batch_size)
    def snapshot():
        return dict(policy=POLICY, signature=signature, config=model.backbone.config.to_dict(),
                    revision=revision, model=model.state_dict(), optimizer=optimizer.state_dict(),
                    scaler=scaler.state_dict(), step=step,epoch=epoch,offset=offset,best=best,bad=bad,
                    history=history, torch_rng=torch.get_rng_state(),
                    cuda_rng=torch.cuda.get_rng_state_all() if device.type=='cuda' else [],
                    source_hashes=meta['source_hashes'], threshold=.5,
                    inference_preprocessing='8k_pcm16_central_3sec_resample16k_no_normalization_pad48000')
    print(f'GPU={device} fit={len(fit):,} internal_dev={len(dev):,} step={step} epoch={epoch}', flush=True)
    print('Threshold=0.5; official Validation is NOT used for training/selection.', flush=True)
    if a.mode == 'benchmark':
        model.train()
        measures = []
        for j,(x,mask,y) in enumerate(DataLoader(fit,batch_size=a.batch_size,collate_fn=collate,shuffle=True)):
            if device.type=='cuda': torch.cuda.synchronize()
            t = time.monotonic()
            optimizer.zero_grad(set_to_none=True)
            with autocast(device):
                loss=torch.nn.functional.binary_cross_entropy_with_logits(model(x.to(device),mask.to(device)), y.float().to(device))
            scaler.scale(loss).backward(); scaler.step(optimizer); scaler.update()
            if device.type=='cuda': torch.cuda.synchronize()
            if j >= 3: measures.append(time.monotonic()-t)
            if j>=22: break
        if not measures:
            raise ValueError('Benchmark requires at least 5 batches')
        # Measure forward+CPU pipeline on a bounded subset, extrapolate explicitly.
        subset=torch.utils.data.Subset(dev, range(min(256,len(dev))))
        ev=evaluate(model,subset,device,a.batch_size)
        result=dict(seconds_per_training_step=sum(measures)/len(measures),
                    estimated_epoch_minutes=sum(measures)/len(measures)*batches/60,
                    estimated_full_validation_minutes=ev['seconds']/len(subset)*111947/60,
                    note='Estimates only; training step excludes loader time. No compute-unit guarantee. Benchmark weights discarded.')
        atomic_json(a.output/'benchmark.json',result)
        print(json.dumps(result,indent=2),flush=True)
        return
    print('Resuming at next saved batch. A disconnect can lose at most save-every unsaved steps.',flush=True)
    while epoch < a.epochs and bad < 4:
        fit.epoch=epoch
        order=torch.randperm(len(fit), generator=torch.Generator().manual_seed(20261010+epoch)).tolist()
        loader=DataLoader(fit,batch_size=a.batch_size,sampler=order[offset:],collate_fn=collate)
        for x,mask,y in loader:
            if a.max_minutes > 0 and time.monotonic()-started >= a.max_minutes*60:
                atomic_save(last,snapshot())
                print('TIME BUDGET REACHED. Saved last_checkpoint.pt. Resume later; no official score yet.',flush=True)
                return
            model.set_stage(step>=a.warmup_steps)
            model.train()
            progress=min(1.,max(0,step-a.warmup_steps)/max(1,a.epochs*batches-a.warmup_steps))
            decay=.1+.9*(1+math.cos(math.pi*progress))/2
            optimizer.param_groups[0]['lr']=1e-5*decay
            optimizer.param_groups[1]['lr']=(1e-3 if step<a.warmup_steps else 3e-4)*decay
            optimizer.zero_grad(set_to_none=True)
            with autocast(device):
                logits=model(x.to(device),mask.to(device))
                loss=torch.nn.functional.binary_cross_entropy_with_logits(logits,y.float().to(device))
            if not torch.isfinite(loss): raise FloatingPointError('Nonfinite loss; keep previous checkpoint')
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
            scaler.step(optimizer); scaler.update()
            step+=1; offset+=len(y)
            if step==1 or step%25==0:
                print(f'step={step} epoch={epoch+1} seen={offset:,}/{len(fit):,} loss={loss.item():.4f} elapsed={(time.monotonic()-started)/60:.1f}min',flush=True)
            if step%a.save_every==0:
                atomic_save(last,snapshot())
            if step%a.eval_every==0 or offset==len(fit):
                result=evaluate(model,dev,device,a.batch_size)
                result.update(step=step,epoch=epoch+1,scope='training_call_holdout_not_official_validation')
                history.append(result)
                improved=result['accuracy']>best
                if improved: best=result['accuracy']; bad=0
                else: bad+=1
                if improved: atomic_save(a.output/'best_model.pt',snapshot())
                atomic_json(a.output/'history.json',history)
                atomic_save(last,snapshot())
                print(f'INTERNAL DEV accuracy={result["accuracy"]:.4%}; best={best:.4%}; NOT official score',flush=True)
                if bad>=4: break
        if offset==len(fit): epoch+=1; offset=0
    atomic_save(last,snapshot())
    print(f'Training stopped. Internal best={best:.4%}. Official full Validation remains to be evaluated.',flush=True)


if __name__=='__main__':
    main()
